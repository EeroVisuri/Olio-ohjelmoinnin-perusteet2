package harjoitustyo.kokoelma;

public class Kokoelma {

}
