package harjoitustyo.omalista;

public class OmaLista {

}
