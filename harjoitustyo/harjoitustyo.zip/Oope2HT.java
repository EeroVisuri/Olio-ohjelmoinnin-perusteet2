package harjoitustyo;

import java.util.Scanner;

public class Oope2HT {

	public static void main(String[] args) {
		
		boolean suoritetaan = true;
		
		while (suoritetaan) {
			System.out.println("Welcome to L.O.T.");
			System.out.println("Please, enter a command:");
		}
		

	}

}
