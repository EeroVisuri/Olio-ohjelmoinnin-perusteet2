package harjoitustyo.dokumentit;
import java.time.*;


public class Uutinen extends Dokumentti {
	private LocalDate päivämäärä;
	
	public LocalDate päivämäärä() {
		return päivämäärä;
	}
	
	public void päivämäärä(LocalDate uusipäivämäärä) {
		if (uusipäivämäärä != null) {
			päivämäärä = uusipäivämäärä;
		}
	}
	
	
	//@Override
	//public String toString() {
	//String original = super.toString();
	//return original.replace("///", "///" + päivämäärä + "///");
	//}
}
