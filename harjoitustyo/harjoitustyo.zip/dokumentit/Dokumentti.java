package harjoitustyo.dokumentit;


import harjoitustyo.apulaiset.*;
import java.util.LinkedList;
import java.util.*;
import java.time.*;

public abstract class Dokumentti implements Comparable <Dokumentti>, Tietoinen <Dokumentti> {
	
	/*
	 * Attribuutit
	 */
	
	private int tunniste;
	
	private String teksti;
	
	/*
	 * Rakentaja
	 */
	
	public Dokumentti(int tunniste, String teksti) throws IllegalArgumentException {
		if (tunniste <= 0 || teksti == null || teksti.length() <= 0) {
			throw new IllegalArgumentException();
		}
		this.teksti = teksti;
		this.tunniste = tunniste;
	}
	
	/*
	 * Aksessorit
	 */
	
	public int tunnite() {
		return tunniste;
	}
	
	public String teksti() {
		return teksti;
	}
	
	public void tunniste(int uusitunniste) {
		if (uusitunniste > 0) {
			tunniste = uusitunniste;
		}
	}
	
	public void teksti (String uusiteksti) {
		if (uusiteksti != null ) {
			teksti = uusiteksti; 
		}
	}
	
	@Override
	public int compareTo(Dokumentti T) {
		if (tunniste == T.tunniste) {
			return 0;
		}
		else if (tunniste >  T.tunniste) {
			return 1;
		}
		else {
			return -1;
		}
	}
	
	//public boolean sanatTäsmäävät() throws IllegalArgumentException {
	//	//täytetään, 2 parametria vissii?
	//}
	
}
