package harjoitustyo.dokumentit;



import java.lang.reflect.Constructor;

public class Vitsi extends Dokumentti {
	private String laji;
	
	public String laji() {
		return laji;
	}
	
	public void laji (String uusilaji) {
		if (uusilaji != null || uusilaji.length() <= 0) {
			laji = uusilaji;
		}
	}
	
	//korvaa toString ketjuttaen superia käyttäen vissiin
	//
	
}