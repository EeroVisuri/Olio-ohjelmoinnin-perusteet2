## Yleistä

WETO käyttää aina alkuperäistä _harjoitustyo.apulaiset_-pakkausta. Pakkauksen
tiedostoja ei siksi ole syytä muuttaa ellet ole Mac- tai Linux-käyttäjä (katso
alla).

Projektipohjan juuressa on _.gitignore_-tiedosto, jolla estetään tavukoodin
tallennus versionhallintaan. Lisää siihen tarvittaessa estoja.

## Mac- ja Linux-käyttäjät

Projektipohjan tiedostojen rivinvaihdot ovat Windows-tyylisiä (CR & LF). Muuta
rivinvaihdot tarvittaessa Mac/Linux-muotoon (LF). Tämä onnistuu todennäköisesti
käyttämälläsi editorilla tai IDE:llä. **Älä muuta** _harjoitustyo.apulaiset_
-pakkausta **millään muulla tavoin**.

## Muuta


Perinteisesti tietovarastoissa on projektista kertova README.md-tiedosto. Korvaa
siksi tämän tiedoston sisältö tekstillä, jossa kuvailet ohjelmaasi omin sanoin.
Kerro lyhyesti mitä ohjelma tekee ja kuinka sitä käytetään. Käytä tekstissä
muotoiluja. Tämän dokumentin mittainen teksti riittää hyvin.
